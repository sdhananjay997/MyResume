package com.resume.myResyme;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyResymeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyResymeApplication.class, args);
	}

}
