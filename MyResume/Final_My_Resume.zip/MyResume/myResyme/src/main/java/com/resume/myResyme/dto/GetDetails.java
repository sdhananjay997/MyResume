package com.resume.myResyme.dto;

public interface GetDetails {

    long getUserId();
    String getUserFirstName();
    String getUserLastName();
    String getUserEmail();
    String getUserMobileNumber();
    String getUserSkills();


}
