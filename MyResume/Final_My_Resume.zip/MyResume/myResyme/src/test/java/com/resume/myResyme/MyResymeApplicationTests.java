package com.resume.myResyme;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyResymeApplicationTests {

	@Test
	void contextLoads() {
	}

}
